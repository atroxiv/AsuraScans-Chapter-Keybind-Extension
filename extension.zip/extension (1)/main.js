
window.addEventListener("keydown", function(event){
    if(event.defaultPrevented){
        return;
    }
    switch(event.key){
        case "ArrowLeft":
            var leftbuttons = document.getElementsByClassName("ch-prev-btn");
            var arr = Array.from(leftbuttons);
            var leftbutton = arr[0].href;
            console.log(leftbutton);
            window.location.href = leftbutton;
        break;

        case "ArrowRight":
            var rightbuttons = document.getElementsByClassName("ch-next-btn");
            var arr1 = Array.from(rightbuttons);
            var rightbutton = arr1[0].href
            window.location.href= rightbutton;
        break;

        default:
            return;
    }
    event.preventDefault();

},true);